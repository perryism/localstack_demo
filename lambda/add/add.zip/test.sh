awslocal lambda invoke --function-name $1 --payload '{"x": 3, "y": 4}' /dev/stdout
